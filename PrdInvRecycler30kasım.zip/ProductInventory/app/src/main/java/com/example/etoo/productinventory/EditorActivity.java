package com.example.etoo.productinventory;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.etoo.productinventory.data.Product;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.google.zxing.Result;
import com.squareup.picasso.Picasso;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import me.dm7.barcodescanner.zxing.ZXingScannerView;

public class EditorActivity extends AppCompatActivity implements ZXingScannerView.ResultHandler {


    private static final int GALLERY_REQUEST = 1;
    private static final int CAMERA_REQUEST_CODE = 2;
    private static final String TAG = "Editor Activity";
    private static boolean editPage = false;
    String barcodeString;
    String ifPhotoIsNotChangedImageUrl = "";
    private ZXingScannerView zXingScannerView;

    private EditText prdName, prdSellingPrice, prdQuantity, prdSupplier, prdSupplierPhone, prdPurchasingPrice, prdBarcode;
    private ImageView prdImage,scanBarcode;
    private ImageButton camera, galeri;
    private FirebaseDatabase mFirebaseDatabase;
    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthListener;
    private DatabaseReference myRef;
    private String userID;
    private StorageReference mStorageRef;
    private Uri mImageUri = null;
    private ProgressBar editPageImageProgressBar;
    private EditText prdGroupName;
    String beforeChangedGroupName;

    /**
     * Content URI for the existing product (null if it's a new product)
     */

    public static void setEditPage(boolean editPage) {
        EditorActivity.editPage = editPage;
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        prdBarcode = findViewById(R.id.barCodeEditText);
        editPageImageProgressBar =findViewById(R.id.imageProgress);

        if (requestCode == CAMERA_REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            editPageImageProgressBar.setVisibility(View.VISIBLE);

            prdImage.setVisibility(View.INVISIBLE);

            final Bitmap bitmap = (Bitmap) data.getExtras().get("data");
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
            byte[] dataBAOS = baos.toByteArray();
            final StorageReference imagesRef = mStorageRef.child(userID).child(prdBarcode.getText().toString());
            final UploadTask uploadTask = imagesRef.putBytes(dataBAOS);

            Task<Uri> urlTask = uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                @Override
                public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                    return imagesRef.getDownloadUrl();
                }
            }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                @Override
                public void onComplete(@NonNull Task<Uri> task) {
                    if (task.isSuccessful()) {
                        Uri downloadUri = task.getResult();
                        mImageUri = Uri.parse(downloadUri.toString());
                        toastMessage("Successfully uploaded");

                        editPageImageProgressBar.setVisibility(View.INVISIBLE);
                        prdImage.setVisibility(View.VISIBLE);
                        prdImage.setImageBitmap(bitmap);
                    } else {
                        toastMessage("Uploading failed");
                    }
                }
            });
        }
        if(requestCode == GALLERY_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null){
           Uri filePath = data.getData();

                //getting image from gallery
            Bitmap bitmap = null;
            try {
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
            } catch (IOException e) {
                e.printStackTrace();
            }

            prdImage.setImageBitmap(bitmap);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
            byte[] dataBAOS = baos.toByteArray();
            final StorageReference imagesRef = mStorageRef.child(userID).child(prdBarcode.getText().toString());
            final UploadTask uploadTask = imagesRef.putBytes(dataBAOS);

            final Bitmap finalBitmap = bitmap;
            Task<Uri> urlTask = uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                @Override
                public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                    return imagesRef.getDownloadUrl();
                }
            }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                @Override
                public void onComplete(@NonNull Task<Uri> task) {
                    if (task.isSuccessful()) {
                        Uri downloadUri = task.getResult();
                        mImageUri = Uri.parse(downloadUri.toString());
                        toastMessage("Successfully uploaded");

                        editPageImageProgressBar.setVisibility(View.INVISIBLE);
                        prdImage.setVisibility(View.VISIBLE);
                        prdImage.setImageBitmap(finalBitmap);
                    } else {
                        toastMessage("Uploading failed");
                    }
                }
            });
        }
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_page);
        editTextFind();
        galeri = findViewById(R.id.galeriButton);
        camera = findViewById(R.id.cameraButton);
        prdImage = findViewById(R.id.editPageImage);
        if (editPage) {
            getEditProduct();
        }
        mAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        myRef = mFirebaseDatabase.getReference();
        FirebaseUser user = mAuth.getCurrentUser();
        userID = user.getUid();

        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user != null) {
                    // User is signed in
                    Log.d(TAG, "onAuthStateChanged:signed_in:" + user.getUid());
                    toastMessage("Successfully signed in with: " + user.getEmail());
                } else {
                    // User is signed out
                    Log.d(TAG, "onAuthStateChanged:signed_out");
                    toastMessage("Successfully signed out.");
                }
            }
        };

        mStorageRef = FirebaseStorage.getInstance().getReference();

        camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!prdBarcode.getText().toString().equals("")) {
                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(intent, CAMERA_REQUEST_CODE);
                }else {
                    toastMessage("Please enter the barcode for uploading an image");
                }
            }
        });

        galeri.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!prdBarcode.getText().toString().equals("")) {

                    Log.d(TAG, "onClick: accessing phones memory.");
                    Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                    intent.setType("image/*");
                    startActivityForResult(intent, GALLERY_REQUEST);
                } else {
                    toastMessage("Please enter the barcode for uploading an image");
                }
            }
        });
    }

    private void editTextFind() {
        prdName = findViewById(R.id.prdName);
        prdSellingPrice = findViewById(R.id.prdSellingPrice);
        prdPurchasingPrice = findViewById(R.id.prdPurchasePrice);
        prdBarcode = findViewById(R.id.barCodeEditText);
        prdQuantity = findViewById(R.id.prdQuantity);
        prdImage = findViewById(R.id.editPageImage);
        prdSupplier = findViewById(R.id.prdSupplier);
        prdSupplierPhone = findViewById(R.id.supplierPhone);
        prdGroupName =  findViewById(R.id.prdGroupName);
    }

    private void updateExistingProduct() {

        editTextFind();

        Product newPrd = new Product();
        newPrd.setProductBarcode(prdBarcode.getText().toString());
        newPrd.setProductName(prdName.getText().toString());
        newPrd.setProductQuantity(prdQuantity.getText().toString());
        newPrd.setPurchasePrice(prdPurchasingPrice.getText().toString());
        newPrd.setSellingPrice(prdSellingPrice.getText().toString());
        newPrd.setProductSupplier(prdSupplier.getText().toString());
        newPrd.setProductSupplierPhone(prdSupplierPhone.getText().toString());
        newPrd.setProductGroup(prdGroupName.getText().toString());
        if(mImageUri != null) {
            newPrd.setImage(mImageUri.toString());
        } else{
            newPrd.setImage(ifPhotoIsNotChangedImageUrl);
        }
            /* Grup ismi değiştirildiğinde kayıt, eski grup ismiyle de kayıtlı olarak kalıyordu.
            @param beforeChangedGroupName stringi listedeki ürün tıklanıp edit sayfası açıldığındaki
            ilk değeri alıyor. Böylece grup ismi değiştirildiğinde (aslında değişmese de varolan değeri null yapıp
            yine varolan değerle yeniden yazıyor) eski kaydı silebiliyor.
            Yine eğer ürün grup ismine sahip değilse AllListte listelendiği için eğer grup ismi girilmişse diye AllList grubundan da siliyor
            Ama grup ismi zaten hiç girilmediyse newPrd.getProductGroup değeri "" değerine eşit oluyor böylece else kısmı çalışıyor.
             */
        if (!newPrd.getProductName().equals("") && !newPrd.getProductBarcode().equals("")) {
            if(!newPrd.getProductGroup().equals("")){
                myRef.child(userID).child(beforeChangedGroupName).child(newPrd.getProductBarcode()).setValue(null);
                myRef.child(userID).child(newPrd.getProductGroup()).child(newPrd.getProductBarcode()).setValue(newPrd);
                myRef.child(userID).child("AllList").child(newPrd.getProductBarcode()).setValue(null);

            } else {
                myRef.child(userID).child("AllList").child(newPrd.getProductBarcode()).setValue(newPrd);
                toastMessage("Product has been updated.");
            }
            finish();
        } else {
            toastMessage("You must fill out and product name field at least to update product");
        }
    }

    private void getEditProduct() {

        editTextFind();

        Bundle extras = getIntent().getExtras();
        if (extras == null) {
            return;
        }
// get data via the key
        String productName = extras.getString("prdName");
        String productQuantity = extras.getString("prdQuantity");
        String productSellingPrice = extras.getString("prdSellingPrice");
        String productPurchasePrice = extras.getString("prdPurchasePrice");
        String productSupplier = extras.getString("prdSupplierName");
        String productSupplierPhone = extras.getString("prdSupplierPhone");
        String productBarcode = extras.getString("prdBarcode");
        String productImageUrl = extras.getString("prdImageUrl");
        String productGroupName = extras.getString("prdGroupName");
        String update = extras.getString("update");


        // If the intent DOES NOT contain a product content URI, then we know that we are
        // creating a new product.
        if (update.equals("update")) {
            // This is a new product, so change the app bar to say "Add a product"
            setTitle(getString(R.string.editor_activity_title_edit_product));
            // Invalidate the options menu, so the "Delete" menu option can be hidden.
            // (It doesn't make sense to delete a product that hasn't been created yet.)
            invalidateOptionsMenu();
        } else {
            // Otherwise this is an existing product, so change app bar to say "Edit product"
            setTitle(getString(R.string.editor_activity_title_new_product));
            // Initialize a loader to read the product data from the database
            // and display the current values in the editor
        }

        if (productName != null) {
            prdName.setText(productName);
        } else {
            prdName.setText("");
        }
        if (productQuantity != null) {
            prdQuantity.setText(productQuantity);
        } else {
            prdQuantity.setText("");
        }
        if (productSellingPrice != null) {
            prdSellingPrice.setText(productSellingPrice);
        } else {
            prdSellingPrice.setText("");
        }
        if (productSupplier != null) {
            prdSupplier.setText(productSupplier);
        } else {
            prdSupplier.setText("");
        }
        if (productPurchasePrice != null) {
            prdPurchasingPrice.setText(productPurchasePrice);
        } else {
            prdSellingPrice.setText("");
        }
        if (productSupplierPhone != null) {
            prdSupplierPhone.setText(productSupplierPhone);
        } else {
            prdSellingPrice.setText("");
        }
        if (productBarcode != null) {
            prdBarcode.setText(productBarcode);
        } else {
            prdSellingPrice.setText("");
        }
        if (!productImageUrl.equals("")) {
            Picasso.get().load(productImageUrl).into(prdImage);
            ifPhotoIsNotChangedImageUrl = productImageUrl;
        } else {
            prdImage.setImageResource(R.drawable.common_google_signin_btn_icon_dark_focused);
        }
        if (!productGroupName.equals("")) {
            prdGroupName.setText(productGroupName);
            beforeChangedGroupName = prdGroupName.getText().toString();
        } else {
            prdGroupName.setText("");        }

    }
/*

    private void barcodeAlert() {
        final AlertDialog.Builder mBuilder = new AlertDialog.Builder(EditorActivity.this);
        final View dialogView = this.getLayoutInflater().inflate(R.layout.update_dialog, null);

        mBuilder.setView(dialogView);
        final AlertDialog dialog = mBuilder.create();

        final EditText barcode = dialogView.findViewById(R.id.barcodeEt);

        Button submitBarcode = dialogView.findViewById(R.id.submitBarcode);
        Button cancelButton = dialogView.findViewById(R.id.cancelButton);

        dialog.setCanceledOnTouchOutside(false);
        dialog.setCancelable(false);
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
                Intent intent = new Intent(EditorActivity.this, InventoryActivity.class);
                startActivity(intent);
                finish();
            }
        });
        submitBarcode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                prdBarcode = findViewById(R.id.barCodeEditText);

                barcodeString = barcode.getText().toString();
                if (!barcodeString.equals("")) {
                    myRef.child(userID).child(barcodeString);
                    prdBarcode.setText(barcodeString);
                    dialog.dismiss();
                } else {
                    toastMessage("Barcode must be entered to create a product");
                }
            }
        });

        dialog.show();
    }
*/

    private void saveProduct() {
        editTextFind();

        Product newPrd = new Product();
        newPrd.setProductName(prdName.getText().toString());
        newPrd.setProductQuantity(prdQuantity.getText().toString());
        newPrd.setSellingPrice(prdSellingPrice.getText().toString());
        newPrd.setPurchasePrice(prdPurchasingPrice.getText().toString());
        newPrd.setProductBarcode(prdBarcode.getText().toString());
        newPrd.setProductSupplier(prdSupplier.getText().toString());
        newPrd.setProductSupplierPhone(prdSupplierPhone.getText().toString());
        newPrd.setProductGroup(prdGroupName.getText().toString());
        //May cause an error
        if(mImageUri != null)
        newPrd.setImage(mImageUri.toString());
        else newPrd.setImage("");
        //handle the exception if the EditText fields are null
        if (!newPrd.getProductName().equals("")&& !newPrd.getProductBarcode().equals("")) {
            if(!prdGroupName.getText().toString().equals("")){
                myRef.child(userID).child(newPrd.getProductGroup()).child(newPrd.getProductBarcode()).setValue(newPrd);
            } else {
                myRef.child(userID).child("AllList").child(newPrd.getProductBarcode()).setValue(newPrd);
                toastMessage("New product has been saved.");
            }
            finish();
        } else {
            toastMessage("You must fill out product name field at least to save product");
        }

    }

    @Override
    public void onBackPressed() {
        // If the product hasn't changed, continue with handling back button press
        new AlertDialog.Builder(this)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setTitle("Exit without saving")
                .setMessage("Are you sure you want to exit without saving ?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                })
                .setNegativeButton("No", null)
                .show();
    }

    /**
     * customizable toast
     * @param message
     */
    private void toastMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu options from the res/menu/editor_menu.xml file.
        // This adds menu items to the app bar.
        getMenuInflater().inflate(R.menu.editor_menu, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        // If this is a new products, hide the "Delete" menu item.
        if (editPage) {
            MenuItem menuItem = menu.findItem(R.id.delete_button);
            menuItem.setVisible(true);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            // Respond to a click on the "Save" menu option
            case R.id.save_button:
                //Save products to database
                if (!editPage) {
                    saveProduct();
                } else {
                    updateExistingProduct();
                }
                //Exit from add new products activity
                //  NavUtils.navigateUpFromSameTask(EditorActivity.this);
                // Respond to a click on the "Delete" menu option
            case R.id.delete_button:
                // Pop up confirmation dialog for deletion

                return true;

            // Respond to a click on the "Up" arrow button in the app bar
            case android.R.id.home:
                // Navigate back to parent activity (CatalogActivity)
                // If the product hasn't changed, continue with navigating up to parent activity
                // which is the {@link CatalogActivity}.
                NavUtils.navigateUpFromSameTask(EditorActivity.this);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void scan(View view){
        zXingScannerView =new ZXingScannerView(getApplicationContext());
        setContentView(zXingScannerView);
        zXingScannerView.setResultHandler(this);
        zXingScannerView.startCamera();

    }
    @Override
    protected void onPause() {
        super.onPause();
       // zXingScannerView.stopCamera();
    }
    @Override
    public void handleResult(Result result) {
        prdBarcode.setText(result.getText());
        zXingScannerView.resumeCameraPreview(this);
    }
}


