package com.example.etoo.productinventory;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.etoo.productinventory.data.Product;
import com.example.etoo.productinventory.data.ProductAdapter;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;


public class InventoryActivity extends AppCompatActivity {

    private static final String TAG = "ViewDatabase";

    private FirebaseDatabase mFirebaseDatabase;
    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthListener;
    private DatabaseReference myRef;
    private String userID;
    private StorageReference mStorageRef;
    private ProgressBar mProgresBar;
    private FloatingActionButton createGroup;
    private FloatingActionButton createItem;
    private boolean isFABOpen;
    private ArrayList<Product> products;
    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(this)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setTitle("Exit from app")
                .setMessage("Are you sure you want to exit ?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }

                })
                .setNegativeButton("No", null)
                .show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.inventory);

        final View emptyList = findViewById(R.id.empty_view);

        //   getSupportActionBar().hide();
        mStorageRef = FirebaseStorage.getInstance().getReference();
        //this will hold pur collection of products
        mAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        myRef = mFirebaseDatabase.getReference();
        final FirebaseUser user = mAuth.getCurrentUser();
        userID = user.getUid();


        final RecyclerView productListView = findViewById(R.id.productList);


        mProgresBar = findViewById(R.id.progressBar);
        myRef.child(userID).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                products = new ArrayList<>();

                int counter = 0;
                //Get all of the children at this level
                Iterable<DataSnapshot> children = dataSnapshot.getChildren();
                //Veriyi alıp Product objesinde kaydediyor. Şu an için log ekranına yazdırabiliyor.
                //ListViewa yazdırmak gerekiyor.
                for (DataSnapshot child : children) {
                            Iterable<DataSnapshot> cocuklar = child.getChildren();
                                for(DataSnapshot cocuk : cocuklar){
                                    counter += 1;
                                    Product prd = cocuk.getValue(Product.class);
                                    products.add(prd);
                                    mProgresBar.setVisibility(View.VISIBLE);
                                }
                }
                final ProductAdapter adapter = new ProductAdapter(getApplicationContext(), products);
                RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(InventoryActivity.this);
                productListView.setLayoutManager(layoutManager);
                productListView.setItemAnimator(new DefaultItemAnimator());
                productListView.setAdapter(adapter);
               if (counter == 0) {
                    emptyList.setVisibility(View.VISIBLE);
                } else {
                    emptyList.setVisibility(View.INVISIBLE);
                }
                mProgresBar.setVisibility(View.INVISIBLE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user != null) {
                    // User is signed in
                    Log.d(TAG, "onAuthStateChanged:signed_in:" + user.getUid());

                } else {
                    // User is signed out
                    Log.d(TAG, "onAuthStateChanged:signed_out");
                    toastMessage("Successfully signed out.");
                }
                // ...
            }
        };

        // Setup FAB to open EditorActivity
        FloatingActionButton fab = findViewById(R.id.fab);
        createGroup = findViewById(R.id.groupFab);
        createItem = findViewById(R.id.itemFab);

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!isFABOpen) {
                    showFABMenu();
                } else {
                    closeFABMenu();
                }
            }
        });

        createGroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                showGroupDialog();
                closeFABMenu();
            }
        });

        createItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(InventoryActivity.this, EditorActivity.class);
                startActivity(intent);
                EditorActivity.setEditPage(false);
                closeFABMenu();
            }
        });
/*

        productListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long id) {

                final Product prd = (Product) adapterView.getAdapter().getItem(position);

                // Create an AlertDialog.Builder and set the message, and click listeners
                // for the postivie and negative buttons on the dialog.
                AlertDialog.Builder builder = new AlertDialog.Builder(InventoryActivity.this);
                builder.setMessage(R.string.delete_dialog_msg);
                builder.setPositiveButton(R.string.delete, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        if(!prd.getProductGroup().equals("")) {
                            // User clicked the "Delete" button, so delete the product.
                            myRef.child(userID).child(prd.getProductGroup()).child(prd.getProductBarcode()).setValue(null);
                            StorageReference userImages = mStorageRef.child(userID).child(prd.getProductBarcode());
                            userImages.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    toastMessage("Prd image also deleted");
                                }
                            });

                        }else{
                            // User clicked the "Delete" button, so delete the product.
                            myRef.child(userID).child("AllList").child(prd.getProductBarcode()).setValue(null);
                            StorageReference userImages = mStorageRef.child(userID).child(prd.getProductBarcode());
                            userImages.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    toastMessage("Prd image also deleted");
                                }
                            });
                    }
                        toastMessage("Product has been deleted.");
                    }
                });
                builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // User clicked the "Cancel" button, so dismiss the dialog
                        // and continue editing the product.
                        if (dialog != null) {
                            dialog.dismiss();
                        }
                    }
                });
                // Create and show the AlertDialog
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
                return true;
            }
        });

        productListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {

                Product prd = (Product) adapterView.getAdapter().getItem(position);

                Intent intent = new Intent(InventoryActivity.this, EditorActivity.class);

                intent.putExtra("prdName", prd.getProductName());
                intent.putExtra("prdSellingPrice", prd.getSellingPrice());
                intent.putExtra("prdPurchasePrice", prd.getPurchasePrice());
                intent.putExtra("prdQuantity", prd.getProductQuantity());
                intent.putExtra("prdSupplierName", prd.getProductSupplier());
                intent.putExtra("prdSupplierPhone", prd.getProductSupplierPhone());
                intent.putExtra("prdBarcode", prd.getProductBarcode());
                intent.putExtra("prdImageUrl", prd.getImage());
                intent.putExtra("prdGroupName", prd.getProductGroup());
                intent.putExtra("update", "update");
                startActivity(intent);
                EditorActivity.setEditPage(true);

            }
        });
        */
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.delete_all) {
            showDeleteConfirmationDialog();

            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void showFABMenu() {
        isFABOpen = true;
        createGroup.animate().translationY(-getResources().getDimension(R.dimen.standard_65));
        createItem.animate().translationY(-getResources().getDimension(R.dimen.standard_125));
    }

    private void closeFABMenu() {
        isFABOpen = false;
        createItem.animate().translationY(0);
        createGroup.animate().translationY(0);
    }

    private void showGroupDialog() {
        final AlertDialog.Builder mBuilder = new AlertDialog.Builder(InventoryActivity.this);
        final View dialogView = this.getLayoutInflater().inflate(R.layout.create_group, null);

        mBuilder.setView(dialogView);
        final AlertDialog dialog = mBuilder.create();

        final EditText groupName = dialogView.findViewById(R.id.groupNameEt);

        Button submitGroup = dialogView.findViewById(R.id.submitGroup);
        Button cancelGroup = dialogView.findViewById(R.id.cancelGroup);


        dialog.setCanceledOnTouchOutside(false);
        dialog.setCancelable(false);
        cancelGroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        submitGroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                myRef.child(userID).child(groupName.getText().toString()).setValue(true);
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    private void showDeleteConfirmationDialog() {
        // Create an AlertDialog.Builder and set the message, and click listeners
        // for the postivie and negative buttons on the dialog.
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.delete_all_products_msg);
        builder.setPositiveButton(R.string.delete, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User clicked the "Delete" button, so delete the product.
               // deleteAllProducts();
            }
        });
        builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User clicked the "Cancel" button, so dismiss the dialog
                // and continue editing the product.
                if (dialog != null) {
                    dialog.dismiss();
                }
            }
        });

        // Create and show the AlertDialog
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

/*
    public void deleteAllProducts() {
        // Bütün ürünleri ve aynı zamanda grupları da siliyor
        // Create an AlertDialog.Builder and set the message, and click listeners
        // for the postivie and negative buttons on the dialog.
        AlertDialog.Builder builder = new AlertDialog.Builder(InventoryActivity.this);
        builder.setMessage("Are you sure ?");
        builder.setPositiveButton(R.string.delete, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User clicked the "Delete" button, so delete the product.
                myRef.child(userID).setValue(null);
                StorageReference userAllItemImages = mStorageRef.child(userID);
                userAllItemImages.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        toastMessage("All products have been deleted.");
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        toastMessage("Images coldn't be deleted");

                    }
                });
            }
        });
        builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User clicked the "Cancel" button, so dismiss the dialog
                // and continue editing the product.
                if (dialog != null) {
                    dialog.dismiss();
                }
            }
        });
        // Create and show the AlertDialog
        AlertDialog alertDialog = builder.create();
        alertDialog.show();

        Log.v("InventoryActivity", " rows deleted from product database");
    }
*/
    @Override
    public void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(mAuthListener);
    }

    @Override
    public void onStop() {
        super.onStop();
        //   if (mAuthListener != null) {
        //     mAuth.removeAuthStateListener(mAuthListener);
        //  }
    }

    /**
     * customizable toast
     *
     * @param message
     */
    private void toastMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}

