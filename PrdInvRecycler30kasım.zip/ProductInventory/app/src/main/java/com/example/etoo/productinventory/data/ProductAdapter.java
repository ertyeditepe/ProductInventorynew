package com.example.etoo.productinventory.data;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;


import com.example.etoo.productinventory.EditorActivity;
import com.example.etoo.productinventory.InventoryActivity;
import com.example.etoo.productinventory.R;
import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ProductViewHolder> {
    private LayoutInflater mInflater;
    ArrayList<Product> objects = new ArrayList<>();
    public ProductAdapter(@NonNull Context context, @NonNull ArrayList<Product> objects) {
        this.objects = objects;
        mInflater = LayoutInflater.from(context);
    }

    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View mView = mInflater.inflate(R.layout.inventory_item,viewGroup, false);
        return new ProductViewHolder(mView,this);
            }

    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder productViewHolder, int position) {
        Product mCurrent = objects.get(position);
        if (mCurrent != null) {
            productViewHolder.itemName.setText(mCurrent.getProductName());
            productViewHolder.sellingPrice.setText(mCurrent.getSellingPrice());
            productViewHolder.itemQuantity.setText(mCurrent.getProductQuantity());

            if(mCurrent.getImage() != null) {
                if (!mCurrent.getImage().equals("")){
                    Picasso.get().load(mCurrent.getImage()).error(R.drawable.add).into(productViewHolder.listItemImage);
                }else {
                    productViewHolder.listItemImage.setImageResource(R.drawable.common_google_signin_btn_icon_dark_focused);
                }
            }else {
                productViewHolder.listItemImage.setImageResource(R.drawable.common_google_signin_btn_icon_dark_focused);
            }
        }
    }

    @Override
    public int getItemCount() {
        return objects.size();
    }


    class ProductViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public final ImageView listItemImage;
        public final TextView sellingPrice,itemQuantity,itemName;
        public final LinearLayout listItem;

        final ProductAdapter mAdapter;

        public ProductViewHolder(@NonNull View itemView, ProductAdapter adapter) {
            super(itemView);
            listItem = itemView.findViewById(R.id.listItem);
            listItemImage = itemView.findViewById(R.id.listImage);
            sellingPrice = itemView.findViewById(R.id.priceView);
            itemQuantity = itemView.findViewById(R.id.quantityView);
            itemName = itemView.findViewById(R.id.nameView);

            mAdapter = adapter;

            listItem.setOnClickListener(this);

        }

        @Override
        public void onClick(View v) {
            Product prd = objects.get(getLayoutPosition());
            Context context = v.getContext();
            Intent intent = new Intent(context, EditorActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

            intent.putExtra("prdName", prd.getProductName());
            intent.putExtra("prdSellingPrice", prd.getSellingPrice());
            intent.putExtra("prdPurchasePrice", prd.getPurchasePrice());
            intent.putExtra("prdQuantity", prd.getProductQuantity());
            intent.putExtra("prdSupplierName", prd.getProductSupplier());
            intent.putExtra("prdSupplierPhone", prd.getProductSupplierPhone());
            intent.putExtra("prdBarcode", prd.getProductBarcode());
            intent.putExtra("prdImageUrl", prd.getImage());
            intent.putExtra("prdGroupName", prd.getProductGroup());
            intent.putExtra("update", "update");
            context.startActivity(intent);
            EditorActivity.setEditPage(true);
        }
    }

}
